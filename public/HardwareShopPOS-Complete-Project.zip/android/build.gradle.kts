// Top-level build file. Configuration here applies to all sub-projects/modules.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android)      apply false
    alias(libs.plugins.kotlin.kapt)         apply false
    alias(libs.plugins.hilt.android)        apply false
    alias(libs.plugins.kotlin.compose)      apply false
    alias(libs.plugins.google.services)     apply false
}
